﻿namespace TeaBagMaker
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.combotea = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.text1 = new System.Windows.Forms.TextBox();
            this.bb = new System.Windows.Forms.Button();
            this.countText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // combotea
            // 
            this.combotea.FormattingEnabled = true;
            this.combotea.Location = new System.Drawing.Point(148, 38);
            this.combotea.Name = "combotea";
            this.combotea.Size = new System.Drawing.Size(152, 20);
            this.combotea.TabIndex = 0;
            this.combotea.SelectedIndexChanged += new System.EventHandler(this.combotea_SelectedIndexChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 8000;
            // 
            // text1
            // 
            this.text1.Location = new System.Drawing.Point(172, 155);
            this.text1.Name = "text1";
            this.text1.ReadOnly = true;
            this.text1.Size = new System.Drawing.Size(100, 21);
            this.text1.TabIndex = 1;
            this.text1.Text = "나중에..";
            // 
            // bb
            // 
            this.bb.Location = new System.Drawing.Point(182, 96);
            this.bb.Name = "bb";
            this.bb.Size = new System.Drawing.Size(75, 23);
            this.bb.TabIndex = 2;
            this.bb.Text = "담그기!";
            this.bb.UseVisualStyleBackColor = true;
            // 
            // countText
            // 
            this.countText.Location = new System.Drawing.Point(334, 38);
            this.countText.Name = "countText";
            this.countText.ReadOnly = true;
            this.countText.Size = new System.Drawing.Size(100, 21);
            this.countText.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 275);
            this.Controls.Add(this.countText);
            this.Controls.Add(this.bb);
            this.Controls.Add(this.text1);
            this.Controls.Add(this.combotea);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combotea;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox text1;
        private System.Windows.Forms.Button bb;
        private System.Windows.Forms.TextBox countText;
    }
}

