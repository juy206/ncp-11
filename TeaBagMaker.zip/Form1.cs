﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Microsoft.VisualBasic;


namespace TeaBagMaker
{
    public partial class Form1 : Form
    {
        string[] tea = new string[]{"홍차", "녹차", "루이보스차", "국화차"};
        String sel = "";
        int CountNum = 0;

        public Form1()
        {
            InitializeComponent();

            for (int i = 0; i < this.tea.Length; i++)
            {
                this.combotea.Items.Add(tea[i]);
            }

            if (tea.Count() > 0)
            {
                this.combotea.SelectedIndex = 0;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < this.tea.Length; i++)
            {
                this.combotea.Items.Add(tea[i]);
            }
            this.sel = text1.Text;

            if (tea.Count() > 0)
            {
                this.combotea.SelectedIndex = 0;
            }
        }

        private void combotea_SelectedIndexChanged(object sender, EventArgs e)
        { 

        }

        private void Bb_Click(object sender, EventArgs e)
        {
            CountNum = Convert.ToInt32(this.countText.Text);
            this.timer1.Enabled = true;
            if (CountNum < 1)
            {
                this.timer1.Enabled = false;
                this.countText.ReadOnly = false;
                this.countText.Text = "";
                this.text1.Text = "티백을 건지세요 !";
            }
            else
            {
                this.countText.Text = "CountNum";
                CountNum--;

            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (CountNum < 1)
            {
                this.timer1.Enabled = false;
                this.countText.ReadOnly = false;
                this.countText.Text = "";
                this.text1.Text = "티백을 건지세요 !";
            }
            else
            {
                this.countText.Text = Convert.ToString(CountNum);
                CountNum--;
                
            }
        }


    }
}
